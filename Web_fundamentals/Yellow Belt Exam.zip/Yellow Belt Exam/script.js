function hide(element) {
    element.remove();
}

